
package ex3;

public class Elemento {
    
    Elemento prox;
    int num;
    
    /**
     * Construtor da classe Elemento
     * @param num 
     */
    Elemento(int num)
    {
        this.num  = num;
        this.prox = null;
    }
    
}
