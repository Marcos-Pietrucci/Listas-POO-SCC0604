package Execucao;

/**
 *
 * @author brcol
 */
public interface Executavel {
    
    public void fazer();
}
