package ex4_servidor;

/**
 *
 * @author brcol
 */
public class Ex4_Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Rodando o servidor
        Servidor server = new Servidor();
        server.rodar();        
    }
}
