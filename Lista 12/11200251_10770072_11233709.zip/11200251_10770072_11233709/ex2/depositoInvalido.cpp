/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   depositoInvalido.cpp
 * Author: Montanari
 * 
 * Created on 19 de Dezembro de 2020, 02:17
 */

#include "depositoInvalido.h"

depositoInvalido::depositoInvalido() : runtime_error("Deposito inválido!") {
}

depositoInvalido::~depositoInvalido() {
}

