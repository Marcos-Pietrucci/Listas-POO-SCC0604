/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilhaCheia.h
 * Author: brcol
 *
 * Created on 16 de Dezembro de 2020, 15:25
 */

#ifndef PILHACHEIA_H
#define PILHACHEIA_H

#include "PilhaExcecao.h"

class PilhaCheia : public PilhaExcecao{
public:
    PilhaCheia();
    virtual ~PilhaCheia();
private:

};

#endif /* PILHACHEIA_H */

