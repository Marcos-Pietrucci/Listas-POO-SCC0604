/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilhaVazia.cpp
 * Author: brcol
 * 
 * Created on 16 de Dezembro de 2020, 15:25
 */

#include "PilhaVazia.h"

PilhaVazia::PilhaVazia() {
    setMessage("A pilha esta vazia!");
}

PilhaVazia::~PilhaVazia() {
}

