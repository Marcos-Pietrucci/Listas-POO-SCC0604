/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilhaVazia.h
 * Author: brcol
 *
 * Created on 16 de Dezembro de 2020, 15:25
 */

#ifndef PILHAVAZIA_H
#define PILHAVAZIA_H

#include "PilhaExcecao.h"

class PilhaVazia : public PilhaExcecao{
public:
    PilhaVazia();
    virtual ~PilhaVazia();
private:

};

#endif /* PILHAVAZIA_H */

