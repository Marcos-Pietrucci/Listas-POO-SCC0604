package ex3;

public class Superpoder {
    private int categoria;
    private String nome;
    
    public Superpoder() {
    }

    public int getCategoria() {
        return categoria;
    }

    public String getNome() {
        return nome;
    }
    
    public void setCategoria(int pCategoria) {
        categoria = pCategoria;
    }
    
    public void setNome(String pNome) {
        nome = pNome;
    }    
}