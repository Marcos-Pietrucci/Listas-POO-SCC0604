package ex1;

import java.util.*;

/**
 * 
 */
public class Conta {

    /**
     * Default constructor
     */
    public Conta() {
    }

    /**
     * 
     */
    private int codigo;

    /**
     * 
     */
    private enumConta tipo;

    /**
     * 
     */
    private float saldo;

    /**
     * 
     */
    private Cliente cliente;



    /**
     * 
     */
    public void getCodigo() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getTipo() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getSaldo() {
        // TODO implement here
    }

    /**
     * @param valor
     */
    public void depositar(float valor) {
        // TODO implement here
    }

    /**
     * @param valor
     */
    public void sacar(float valor) {
        // TODO implement here
    }

    /**
     * @param valor 
     * @param conta
     */
    public void transferir(float valor, Cliente conta) {
        // TODO implement here
    }

    /**
     * 
     */
    public void getCliente() {
        // TODO implement here
    }

}