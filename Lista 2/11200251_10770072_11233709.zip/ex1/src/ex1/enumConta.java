package ex1;

/**
 * 
 */
public enum enumConta {
    contaCorrente,
    contaPoupanca
}