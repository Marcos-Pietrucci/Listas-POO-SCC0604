package ex1;

import java.util.*;

/**
 * 
 */
public class Banco {

    /**
     * Default constructor
     */
    public Banco() {
    }

    /**
     * 
     */
    private String razao;

    /**
     * 
     */
    private String nome;

    /**
     * 
     */
    private int cnpj;

    /**
     * 
     */
    private ArrayList<Gerente> gerentes;

    /**
     * 
     */
    private ArrayList<Cliente> clientes;



    /**
     * 
     */
    public void getRazao() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getNome() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getCnpj() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getGerentes() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getClientes() {
        // TODO implement here
    }

}