package ex1;

import java.util.*;

/**
 * 
 */
public class Cartao {

    /**
     * Default constructor
     */
    public Cartao() {
    }

    /**
     * 
     */
    private int numero;

    /**
     * 
     */
    private int vencimento;

    /**
     * 
     */
    private Cliente cliente;

    /**
     * 
     */
    private float limite;

    /**
     * 
     */
    private boolean bloqueado;

    /**
     * 
     */
    private enumCartao tipo;


    /**
     * 
     */
    public void getNumero() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getVencimento() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getCliente() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getLimite() {
        // TODO implement here
    }

    /**
     * 
     */
    public void isBloqueado() {
        // TODO implement here
    }

    /**
     * @param valor 
     * @param parcelas
     */
    public void operacao(float valor, int parcelas) {
        // TODO implement here
    }

}