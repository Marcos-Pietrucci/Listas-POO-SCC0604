package ex1;

/**
 * 
 */
public enum enumCartao {
    nacional,
    internacional
}