package ex1;

import java.util.*;

/**
 * 
 */
public class Cliente extends Pessoa_fisica {

    /**
     * Default constructor
     */
    public Cliente() {
    }

    /**
     * 
     */
    private Gerente gerente;

    /**
     * 
     */
    private ArrayList<Conta> contas;

    /**
     * 
     */
    private ArrayList<Cartao> cartoes;




    /**
     * 
     */
    public void getContas() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getGerente() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getCartoes() {
        // TODO implement here
    }

}