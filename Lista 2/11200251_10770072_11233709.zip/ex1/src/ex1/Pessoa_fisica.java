package ex1;

import java.util.*;

/**
 * 
 */
public class Pessoa_fisica {

    /**
     * Default constructor
     */
    public Pessoa_fisica() {
    }

    /**
     * 
     */
    private int codigo;

    /**
     * 
     */
    private String nome;

    /**
     * 
     */
    private int cpf;

    /**
     * 
     */
    private int rg;

    /**
     * 
     */
    private int idade;

    /**
     * 
     */
    private String sexo;

    /**
     * 
     */
    private enumFuncao funcao;




    /**
     * 
     */
    public void getCodigo() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getNome() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getCpf() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getRG() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getIdade() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getSexo() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getFuncao() {
        // TODO implement here
    }

}