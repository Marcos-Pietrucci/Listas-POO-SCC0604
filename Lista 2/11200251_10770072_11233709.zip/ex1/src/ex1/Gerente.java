package ex1;

import java.util.*;

/**
 * 
 */
public class Gerente extends Pessoa_fisica {

    /**
     * Default constructor
     */
    public Gerente() {
    }

    /**
     * 
     */
    private float salario;

    /**
     * 
     */
    private String setor;

    /**
     * 
     */
    private ArrayList<Cliente> clientes;


    /**
     * 
     */
    public void getSalario() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getSetor() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getClientes() {
        // TODO implement here
    }

    /**
     * @param cliente 
     * @param tipo
     */
    public void pedirConta(Cliente cliente, enumConta tipo) {
        // TODO implement here
    }

    /**
     * @param cliente 
     * @param tipo
     */
    public void pedirCartao(Cliente cliente, enumCartao tipo) {
        // TODO implement here
    }

    /**
     * @param cliente 
     * @param valor
     */
    public void pedirEmprestimo(Cliente cliente, float valor) {
        // TODO implement here
    }

}