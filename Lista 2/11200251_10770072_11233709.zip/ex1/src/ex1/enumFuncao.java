package ex1;

/**
 * 
 */
public enum enumFuncao {
    cliente,
    gerente
}