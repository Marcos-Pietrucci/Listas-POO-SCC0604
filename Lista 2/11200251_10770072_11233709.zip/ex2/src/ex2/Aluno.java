package ex2;
import java.util.*;

/**
 * 
 */
public class Aluno {

    /**
     * Default constructor
     */
    public Aluno() {
    }

    /**
     * 
     */
    private String Nome;

    /**
     * 
     */
    private int Idade;

    /**
     * 
     */
    private int AnoIngresso;


    /**
     * @return
     */
    public String getNome() {
        // TODO implement here
        return "";
    }

}