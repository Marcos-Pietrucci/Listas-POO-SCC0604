package ex2;
import java.util.*;

/**
 * 
 */
public class Turma {

    /**
     * Default constructor
     */
    public Turma() {
    }

    /**
     * 
     */
    private int QtdeAlunos;

    /**
     * 
     */
    private String Representante;

    /**
     * 
     */
    private int Ano_turma;



    /**
     * @return
     */
    public int getQtdeAlunos() {
        // TODO implement here
        return 0;
    }

    /**
     * @param aluno
     */
    public void matriculaAluno(Matricula aluno) {
        // TODO implement here
    }

}