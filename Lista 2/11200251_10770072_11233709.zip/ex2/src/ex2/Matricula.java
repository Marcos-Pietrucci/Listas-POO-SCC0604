package ex2;
import java.util.*;

/**
 * 
 */
public class Matricula {

    /**
     * Default constructor
     */
    public Matricula() {
    }

    /**
     * 
     */
    private int Numero;

    /**
     * 
     */
    private double MediaPonderada;



    /**
     * @param ponderada
     */
    public void setPonderada(double ponderada) {
        // TODO implement here
    }

    /**
     * 
     */
    public void excluirMatricula() {
        // TODO implement here
    }

}