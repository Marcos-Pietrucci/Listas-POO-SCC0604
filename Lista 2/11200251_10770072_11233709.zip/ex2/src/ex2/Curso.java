package ex2;
import java.util.*;

/**
 * 
 */
public class Curso {

    /**
     * Default constructor
     */
    public Curso() {
    }

    /**
     * 
     */
    private String Nome;

    /**
     * 
     */
    private String Coordenador;

    /**
     * 
     */
    private int Duracao;



    /**
     * @return
     */
    public String getNome() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public int getDuracao() {
        // TODO implement here
        return 0;
    }

}